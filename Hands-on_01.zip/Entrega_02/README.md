# Hands-on 01: Uso de modelos de propagação para análises sistêmicas

Para executar o código da Entrega_02 basta digitar 'Entrega_02' (sem aspas) no console do MATLAB.

Link do video: https://www.youtube.com/watch?v=5ir-MS1YSiY&t=15s