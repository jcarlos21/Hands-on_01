# Hands-on 01: Uso de modelos de propagação para análises sistêmicas

Para executar o código da Entrega_03 basta digitar 'Entrega_03' (sem aspas) no console do MATLAB.

Link do video: https://www.youtube.com/watch?v=v0uZKAFr3oQ