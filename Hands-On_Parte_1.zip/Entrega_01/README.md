# Hands-on 01: Uso de modelos de propagação para análises sistêmicas

Para executar o código da Entrega_01 basta digitar 'Entrega_01' (sem aspas) no console do MATLAB.